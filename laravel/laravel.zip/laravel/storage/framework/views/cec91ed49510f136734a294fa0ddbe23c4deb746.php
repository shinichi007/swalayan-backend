<?php $__env->startSection('main'); ?>
<main id="main-container">
    <div class="bg-body-light">
      <div class="content content-full">
        <div class="d-flex flex-column flex-sm-row justify-content-sm-between align-items-sm-center">
          <h1 class="flex-grow-1 fs-3 fw-semibold my-2 my-sm-3">Daftar Customer</h1>
          <nav class="flex-shrink-0 my-2 my-sm-0 ms-sm-3" aria-label="breadcrumb">
            <ol class="breadcrumb">
              <li class="breadcrumb-item">Customer</li>
              <li class="breadcrumb-item active" aria-current="page">Daftar Customer</li>
            </ol>
          </nav>
        </div>
      </div>
    </div>

    <div class="content">
      <div class="block block-rounded">
        <div class="block-content text-center">
            <div class="block-content block-content-full">
                <table class="table table-bordered table-striped table-vcenter js-dataTable-buttons">
                  <thead>
                    <tr>
                      <th class="text-center" style="width: 80px;">No</th>
                      <th>Nama</th>
                      <th class="d-none d-sm-table-cell" style="width: 30%;">Email</th>
                      <th class="d-none d-sm-table-cell" style="width: 15%;">No HP</th>
                      <th style="width: 15%;">Tipe</th>
                    </tr>
                  </thead>
                  <tbody>
                    <?php $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                      <td class="text-center"><?php echo e(++$key); ?></td>
                      <td class="fw-semibold">
                        <a href="customer/<?php echo e($customer["id"]); ?>"><?php echo e($customer["data"]["name"]); ?></a>
                      </td>
                      <td class="d-none d-sm-table-cell"><em class="text-muted"><?php echo e($customer["data"]["email"]); ?></em>
                      </td>
                      <td>
                          <em class="text-muted"><?php echo e($customer["data"]["phone"]); ?></em>
                        </td>
                        <td class="d-none d-sm-table-cell">
                          <span class="badge <?php echo e(($customer["member"]["status"] === "member") ? 'bg-success' : 'bg-info'); ?>"><?php echo e(($customer["member"]["status"] === "member") ? 'Member' : 'Non Member'); ?></span>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                   
                  </tbody>
                </table>
              </div>
        </div>
      </div>
    </div>
  </main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/wijayacode/Projects/jm-swalayan/resources/views/customers.blade.php ENDPATH**/ ?>