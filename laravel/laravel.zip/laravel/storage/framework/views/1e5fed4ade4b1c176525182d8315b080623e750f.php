<?php $__env->startSection('main'); ?>
    <main id="main-container">
        <div class="bg-body-light">
            <div class="content content-full">
                <div class="d-flex flex-column flex-sm-row justify-content-sm-between align-items-sm-center">
                    <h1 class="flex-grow-1 fs-3 fw-semibold my-2 my-sm-3">Pengaturan</h1>
                </div>
            </div>
        </div>
        <div class="content">
            <div class="block block-rounded">
                
            </div>
        </div>
    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/wijayacode/Projects/jm-swalayan/resources/views/settings.blade.php ENDPATH**/ ?>