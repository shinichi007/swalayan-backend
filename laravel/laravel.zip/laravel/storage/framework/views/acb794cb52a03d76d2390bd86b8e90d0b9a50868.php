<?php $__env->startSection('main'); ?>
<main id="main-container">
    <div class="bg-body-light">
        <div class="content content-full">
            <div class="d-flex flex-column flex-sm-row justify-content-sm-between align-items-sm-center">
                <h1 class="flex-grow-1 fs-3 fw-semibold my-2 my-sm-3">Daftar User</h1>
                <nav class="flex-shrink-0 my-2 my-sm-0 ms-sm-3" aria-label="breadcrumb">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item">User</li>
                        <li class="breadcrumb-item active" aria-current="page">Daftar User</li>
                    </ol>
                </nav>
            </div>
        </div>
    </div>
    <div class="content">
        <div class="block block-rounded">
            <ul class="nav nav-tabs nav-tabs-block align-items-center" role="tablist">
                <li class="nav-item">
                    <button class="nav-link active" id="btabs-static-admin-tab" data-bs-toggle="tab"
                        data-bs-target="#btabs-static-admin" role="tab" aria-controls="btabs-static-admin"
                        aria-selected="true">Admin</button>
                </li>
                <li class="nav-item">
                    <button class="nav-link" id="btabs-static-operator-tab" data-bs-toggle="tab"
                        data-bs-target="#btabs-static-operator" role="tab" aria-controls="btabs-static-operator"
                        aria-selected="false">Operator</button>
                </li>
                <li class="nav-item ms-auto">
                    <div class="btn-group btn-group-sm pe-2">
                      <button type="button" class="btn btn-alt-secondary">
                        <i class="fa fa-fw fa-add"></i> Tambah
                      </button>
                    </div>
                  </li>
            </ul>
            <div class="block-content tab-content">
                <div class="tab-pane active" id="btabs-static-admin" role="tabpanel"
                    aria-labelledby="btabs-static-admin-tab" tabindex="0">
                    <table class="table table-bordered table-striped table-vcenter js-dataTable-buttons">
                        <thead>
                            <tr>
                                <th class="text-center">No</th>
                                <th class="text-center">Nama</th>
                                <th class="d-none d-sm-table-cell text-center">Email</th>
                                <th class="d-none d-sm-table-cell text-center">No HP</th>
                                <th class="text-center">Status</th>
                            </tr>
                        </thead>
                        <tbody>
                                <tr>
                                    <td class="text-center">1</td>
                                    <td class="fw-semibold">Ujang
                                    </td>
                                    <td class="d-none d-sm-table-cell"><em
                                            class="text-muted">ujang@gmail.com</em>
                                    </td>
                                    <td class="text-center">
                                        <em class="text-muted">089529303412</em>
                                    </td>
                                    <td class="d-none d-sm-table-cell text-center">
                                        <span class="badge bg-success">
                                            Admin</span>
                                    </td>
                                </tr>
                        </tbody>
                    </table>
                </div>
                <div class="tab-pane" id="btabs-static-operator" role="tabpanel"
                    aria-labelledby="btabs-static-operator-tab" tabindex="1">
                    <table class="table table-bordered table-striped table-vcenter js-dataTable-buttons">
                        <thead>
                            <tr>
                                <th class="text-center">No</th>
                                <th class="text-center">Nama</th>
                                <th class="d-none d-sm-table-cell text-center">Email</th>
                                <th class="d-none d-sm-table-cell text-center">No HP</th>
                                <th class="text-center">Status</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td class="text-center">1</td>
                                <td class="fw-semibold">Abdul
                                </td>
                                <td class="d-none d-sm-table-cell"><em
                                        class="text-muted">abdul@gmail.com</em>
                                </td>
                                <td class="text-center">
                                    <em class="text-muted">085156565729</em>
                                </td>
                                <td class="d-none d-sm-table-cell text-center">
                                    <span class="badge bg-info">
                                        Operator</span>
                                </td>
                            </tr>
                    </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/wijayacode/Projects/jm-swalayan/resources/views/users.blade.php ENDPATH**/ ?>